﻿Public Class GAJI
    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cmbNIP.Items.Add("001")
        cmbNIP.Items.Add("002")
        cmbNIP.Items.Add("003")

        cmbGolongan.Items.Add("IIIA")
        cmbGolongan.Items.Add("IIIB")
        cmbGolongan.Items.Add("IIIC")
        cmbGolongan.Items.Add("IIID")
        cmbGolongan.Items.Add("IVA")

        cmbJabatan.Items.Add("KaBag")
        cmbJabatan.Items.Add("KaSub")

        cmbNIP.Select()
    End Sub

    Private Sub cmbNIP_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbNIP.SelectedIndexChanged
        Select Case cmbNIP.Text
            Case "001"
                tNama.Text = "Bayu Aji Pamungkas"
            Case "002"
                tNama.Text = "Dhika Dwi Putra"
            Case "003"
                tNama.Text = "Silvi Novebri"
            Case Else
                tNama.Text = ""
        End Select
    End Sub

    Private Sub cmbGolongan_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbGolongan.SelectedIndexChanged
        Select Case cmbGolongan.Text
            Case "IIIA"
                tGaji.Text = 2500000
            Case "IIIB"
                tGaji.Text = 2750000
            Case "IIIC"
                tGaji.Text = 3500000
            Case "IIID"
                tGaji.Text = 3750000
            Case "IVA"
                tGaji.Text = 4500000
            Case Else
                tGaji.Text = 0
        End Select
    End Sub

    Private Sub cmbJabatan_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbJabatan.SelectedIndexChanged
        Select Case cmbJabatan.Text
            Case "KaBag"
                tTunjangan.Text = 1500000
            Case "KaSub"
                tTunjangan.Text = 1000000
            Case Else
                tTunjangan.Text = 0
        End Select
    End Sub

    Private Sub btnHapus_Click(sender As Object, e As EventArgs) Handles btnHapus.Click
        cmbNIP.Text = ""
        cmbGolongan.Text = ""
        cmbJabatan.Text = ""
        tNama.Text = ""
        tGaji.Text = ""
        tTotal.Text = ""
        tTunjangan.Text = ""
        cmbNIP.Select()
    End Sub

    Private Sub btnProses_Click(sender As Object, e As EventArgs) Handles btnProses.Click
        tTotal.Text = Val(tGaji.Text) + Val(tTunjangan.Text)
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
End Class