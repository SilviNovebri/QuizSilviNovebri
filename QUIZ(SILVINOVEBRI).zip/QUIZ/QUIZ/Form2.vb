﻿Public Class PENJUALAN
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cmbjenis.Items.Add("Seafood")
        cmbjenis.Items.Add("Ayam")
        cmbjenis.Items.Add("Mie")
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbjenis.SelectedIndexChanged
        If cmbjenis.Text = "Seafood" Then
            cmbnama.Items.Clear()
            cmbnama.Text = ""
            cmbnama.Items.Add("Kepiting")
            cmbnama.Items.Add("Kerang")
            cmbnama.Items.Add("Gong Gong")

        ElseIf cmbjenis.Text = "Ayam" Then
            cmbnama.Items.Clear()
            cmbnama.Text = ""
            cmbnama.Items.Add("Ayam Goreng")
            cmbnama.Items.Add("Ayam Bakar")
            cmbnama.Items.Add("Ayam Geprek")

        ElseIf cmbjenis.Text = "Mie" Then
            cmbnama.Items.Clear()
            cmbnama.Text = ""
            cmbnama.Items.Add("Mie Rebus")
            cmbnama.Items.Add("Mie Goreng")
            cmbnama.Items.Add("Mie Lembab")
        End If
    End Sub

    Private Sub Label9_Click(sender As Object, e As EventArgs) Handles Label9.Click

    End Sub

    Private Sub cmbnama_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbnama.SelectedIndexChanged
        If cmbnama.Text = "Kepiting" Then
            txtharga.Text = 95000
        ElseIf cmbnama.Text = "Kerang" Then
            txtharga.Text = 60000
        ElseIf cmbnama.Text = "Gong Gong" Then
            txtharga.Text = 85000
        ElseIf cmbnama.Text = "Ayam Goreng" Then
            txtharga.Text = 15000
        ElseIf cmbnama.Text = "Ayam Bakar" Then
            txtharga.Text = 22000
        ElseIf cmbnama.Text = "Ayam Geprek" Then
            txtharga.Text = 25000
        ElseIf cmbnama.Text = "Mie Rebus" Then
            txtharga.Text = 15000
        ElseIf cmbnama.Text = "Mie Goreng" Then
            txtharga.Text = 19000
        ElseIf cmbnama.Text = "Mie Lembab" Then
            txtharga.Text = 25000
        End If
    End Sub

    Private Sub btnhitung_Click(sender As Object, e As EventArgs) Handles btnhitung.Click
        txttotal.Text = Val(txtharga.Text) * Val(txtjumlah.Text)
        If txttotal.Text > 500000 Then
            txtpotongan.Text = 50000
        Else
            txtpotongan.Text = 0
        End If
        txtbayar.Text = Val(txttotal.Text) - Val(txtpotongan.Text)
    End Sub

    Private Sub btnbatal_Click(sender As Object, e As EventArgs) Handles btnbatal.Click
        End
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Close()
    End Sub
End Class