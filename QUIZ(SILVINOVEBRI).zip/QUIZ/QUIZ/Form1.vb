﻿Public Class Form1
    Private Sub DATAGAJIKARYAWANToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DATAGAJIKARYAWANToolStripMenuItem.Click
        GAJI.Show()
    End Sub

    Private Sub PENJUALANToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PENJUALANToolStripMenuItem.Click
        PENJUALAN.Show()
    End Sub
End Class
